import tkinter as tk
class TkGuiApp(object):# class _main
    def __init__(self,errorl=0,l=1,debugmode=False) -> None:# class _main
        import tkinter as tk# import random,sys,tkinter as tk
        from tkinter import simpledialog# from tkinter import simpledialog
        from tkinter import messagebox# from tkinter import messagebox
        self.tk=tk
        self.messagebox=messagebox
        self.simpledialog=simpledialog
    def init(self):
        self.root=self.tk.Tk()
        self.root.withdraw()
    def inputbox(self,text):
        return self.simpledialog.askstring('quiz', text)# askstring quiz text
    def mbox(self,text):# mbox
        self.messagebox.showinfo('message', text)
    def yesnobox(self,text):
        return self.messagebox.askyesno('message', text)
app=TkGuiApp();app.init()
root=tk.Tk()

root.mainloop()