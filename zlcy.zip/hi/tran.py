import zlcython

zlcython.tran_code_f('test1.zlcy', 'out.py')