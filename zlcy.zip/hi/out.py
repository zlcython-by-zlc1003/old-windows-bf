# -*- coding: utf-8 -*-
#!python3



print('a')
print('b')
print('c')
print('d')
print('e')
print('f')
print('g')


